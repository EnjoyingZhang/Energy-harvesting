% clear all; clc;

%N=[1:4,5:5:25];
N=[4];

Pd_dBm=20;
Pd=10^(Pd_dBm/10)/(10^3);
% Pd_dB=15;
% Pd=10^(Pd_dB/10);
num_loop_N=1*ones(1,length(N));
%Ps_dBm=20;
Ps_dBm=[1:4,5:5:30];
Ps=10.^(Ps_dBm./10)./(10^3);
% Ps_dB=10;
% Ps=10^(Ps_dB/10);

sigma_dBm=-10;
sigma=10^(sigma_dBm/10)/(10^3);
sigmaD=sigma;
sigmaE=sigma;

sigmaA_dBm=sigma_dBm/2;
sigmaA=10^(sigmaA_dBm/10)/(10^3);
sigmaB=sigmaA;

lambdaA=1; lambdaC=1; lambdaB=1;
% eta1=0.5; eta2=0.5;
m=2;
d1= 5;   % the distance between the source and the relay
d2= 5 ;   % the distance between the relay and the destination
d3= 2.5;   % the distance between the destination and the eavesdropper
d4= 2.5;   % the distance between the relay and the eavesdropper
 d5= 7.5;   % the distance between the source and the eavesdropper

for loop_rate=1:length(N)
    for Ps_loop=1:length(Ps)
        N(loop_rate)
        i=0;
        Cs=0;
        Cs_max=0;
        % for loop_ch=1:num_loop_N(loop_rate)
        loop_ch=1;
        % the channel gain
        h=sqrt(1/2)*(randn(N(loop_rate),1)+j*randn(N(loop_rate),1));
        f=sqrt(1/2)*(randn(N(loop_rate),1)+j*randn(N(loop_rate),1));
        g=sqrt(1/2)*(randn(1,N(loop_rate))+j*randn(1,N(loop_rate)));
        c=sqrt(1/2)*(randn(1,1)+j*randn(1,1));
        e=sqrt(1/2)*(randn(1,N(loop_rate))+j*randn(1,N(loop_rate)));
        q=sqrt(1/2)*(randn(1,1)+j*randn(1,1));
        
        for alpha=0.01:0.01:0.99
%            for alpha=0
%              for rho=0.01:0.01:0.99
           for rho=0
                
                i=i+1;
       
                G2(loop_rate,Ps_loop) =2*(alpha+(1-alpha)*rho/2)*(24./(1+exp(-0.1689*(Ps(Ps_loop)./d1^2.*norm(h,2)+Pd./d2^2.*norm(f,2)-16.2083))))./((1-alpha)*((1-rho)*((Ps(Ps_loop)./d1^2.*norm(h,2)+Pd./d2^2.*norm(f,2)+N(loop_rate)*sigmaA)+N(loop_rate)*sigmaB)));
                a1=d1^m*sigmaA; 
                b1=d1^m*sigmaB / (1-rho);
                c1(loop_rate,Ps_loop)=d1^m*d2^m*sigmaD / ((1-rho) .* G2(loop_rate,Ps_loop));
                t=(1-alpha)/(2*log(2));
                
                ECd=capaD(N(loop_rate),Ps(Ps_loop),lambdaA,a1,b1,c1(loop_rate,Ps_loop),t);
                
                a2(Ps_loop)=Pd*d5^m/(d3^m*Ps(Ps_loop));
                b2(Ps_loop)=d5^m*sigmaE/Ps(Ps_loop);
                    
                a3(Ps_loop)=d1^m*sigmaA/Ps(Ps_loop);
                b3(Ps_loop)=d1^m*sigmaA/((1-rho)*Ps(Ps_loop));
                c3(Ps_loop)=Pd*d1^m/(Ps(Ps_loop)*d2^m);
                w(loop_rate,Ps_loop)=d1^m*d4^m*sigmaE./(G2(loop_rate,Ps_loop).*(1-rho).*Ps(Ps_loop));
                
                ECe=capaE(N(loop_rate),lambdaB,lambdaC,a2(Ps_loop),b2(Ps_loop),a3(Ps_loop),b3(Ps_loop),c3(Ps_loop),w(loop_rate,Ps_loop),t);
                
                EC=ECd-ECe;
                
                if EC < 0 | isnan( EC )
                    Cs(Ps_loop,i) =0;
                else
                    Cs(Ps_loop,i)=EC;
                end
                
            end
        end
        Cs_max(loop_ch)=max( Cs(Ps_loop,:) );
        %  end
        Cs_avg(loop_rate,Ps_loop)=mean(Cs_max)
    end
    plot(Ps_dBm,Cs_avg(loop_rate,:),'k-s')
    hold on;
  
end

% 
%   plot(Ps_dBm,Cs_avg,'y-o')
%     xlabel('N');
%     ylabel('$\bar{C}_s$ (bit/s/Hz)','interpreter','latex');
%     title('P_s=20dBm,P_d=30dBm,\sigma^2=-10dBm,\eta_1=0.5,\eta_2=0.5');
%     grid on;
%     hold on;
% hold off;
