function ECe = capaE(N,lambdaB,lambdaC,a2,b2,a3,b3,c3,w,t)

% t=(1-alpha)/(2*log(2));

x1=@(z) lambdaC./(lambdaC+a2.*z).*exp(-z.*b2)./(1+z);
x2=@(phi) (lambdaB./(lambdaB+c3.*phi)).*exp(-phi.*(a3+b3)).*(2*(w.*phi).^(N/2)./gamma(N).* besselk( N,2*sqrt( w.*phi ) ))./(1+phi); 
x3=@(phi,z) lambdaC./(lambdaC+a2.*z).*exp(-z.*b2).*(lambdaB./(lambdaB+c3.*phi)).*exp(-phi.*(a3+b3)).*(2*(w.*phi).^(N/2)./gamma(N).* besselk( N,2*sqrt( w.*phi ) ))./(1+z+phi).^2;

M1=integral( x1,0,inf );
M2=integral( x2,0,inf );
M3=integral2( x3,0,inf,0,inf );
ECe=t*(M1+M2-M3);

