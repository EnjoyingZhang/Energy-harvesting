function ECd=capaD(N,lambdaA,Ps,a1,b1,c1,t)
% % syms z
% % t=( 1-alpha )/( 2*log(2) );
x1=@(z) ( 1-lambdaA./( lambdaA+Ps*z ) ).*2.*exp(-a1-b1).*( c1*z ).^(N/2)./gamma(N).*besselk( N,2*sqrt( c1.*z ) )./z;
% F=t*int(y,z,0,+inf);
ECd = t*integral( x1,0,inf );
