function ECd=capatD(N,Ps,lambdaA,a1,b1,c1,t)
f=@(z) (1-lambdaA./(lambdaA + Ps*z)).*2.*exp(-a1-b1).*(z.*c1).^(N/2)./gamma(N).*besselk( N,2*sqrt(c1.*z))./z;
% f=@(z) ( 1-lambdaA./( lambdaA+Ps*z ) )*exp(-a1-b1)*2.*( z.*c1).^(N./2)./gamma(N).*besselk( N,2*sqrt( c1.*z ) )./z;
% F=t*int(y,z,0,+inf)
ECd=t*integral( f,0,inf );