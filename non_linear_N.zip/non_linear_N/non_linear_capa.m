% clear all; clc;

N=[1:4,5:5:30];
Pd_dBm=20;
Pd=10^(Pd_dBm/10)/(10^3);
% Pd_dB=15;
% Pd=10^(Pd_dB/10);
num_loop_N=1*ones(1,length(N));
Ps_dBm=20;
Ps=10^(Ps_dBm/10)/(10^3);
% Ps_dB=10;
% Ps=10^(Ps_dB/10);

sigma_dBm=-10;
sigma=10^(sigma_dBm/10)/(10^3);
sigmaD=sigma;
sigmaE=sigma;

sigmaA_dBm=sigma_dBm/2;
sigmaA=10^(sigmaA_dBm/10)/(10^3);
sigmaB=sigmaA;

lambdaA=1; lambdaC=1; lambdaB=1;
% eta1=0.5; eta2=0.5;
m=2;
d1= 5;   % the distance between the source and the relay
d2= 5 ;   % the distance between the relay and the destination
d3= 2.5;   % the distance between the destination and the eavesdropper
d4= 2.5;   % the distance between the relay and the eavesdropper
d5= 7.5;   % the distance between the source and the eavesdropper
%  d1= 1;   % the distance between the source and the relay
%  d2= 1;   % the distance between the relay and the destination
%  d3= 1;   % the distance between the destination and the eavesdropper
%  d4= 1;   % the distance between the relay and the eavesdropper
%  d5= 1;   % the distance between the source and the eavesdropper



for loop_rate=1:length(N)
    N(loop_rate)
    i=1; 
    Cs=0;
    Cs_max=0;
    for loop_ch=1:num_loop_N(loop_rate)

        % the channel gain
        h=sqrt(1/2)*(randn(N(loop_rate),1)+j*randn(N(loop_rate),1));
        f=sqrt(1/2)*(randn(N(loop_rate),1)+j*randn(N(loop_rate),1));
        g=sqrt(1/2)*(randn(1,N(loop_rate))+j*randn(1,N(loop_rate)));
        c=sqrt(1/2)*(randn(1,1)+j*randn(1,1));
        e=sqrt(1/2)*(randn(1,N(loop_rate))+j*randn(1,N(loop_rate)));
        q=sqrt(1/2)*(randn(1,1)+j*randn(1,1));
        
%              for alpha=0.01:0.01:0.99
              for alpha=0
                    for rho=0.01:0.01:0.99
%                         for rho=0
                    i=i+1;
                    G2(loop_rate) =2*(alpha+(1-alpha)*rho/2)*(24./(1+exp(-0.1689*(Ps./d1^2.*norm(h,2)+Pd./d2^2.*norm(f,2)-16.2083))))./((1-alpha)*((1-rho)*((Ps./d1^2.*norm(h,2)+Pd./d2^2.*norm(f,2)+N(loop_rate)*sigmaA)+N(loop_rate)*sigmaB)));
                    a1=d1^m*sigmaA;
                    b1=d1^m*sigmaB / (1-rho);
                    c1(loop_rate)=d1^m*d2^m*sigmaD ./ ((1-rho) * G2(loop_rate));
                    t=( 1-alpha )/( 2*log(2) );
               
                    ECd=capatD(N(loop_rate),Ps,lambdaA,a1,b1,c1(loop_rate),t);
                    
                    a2=Pd*d5^m/(d3^m*Ps);
                    b2=d5^m*sigmaE/Ps;
                    
                    a3=d1^m*sigmaA/Ps;
                    b3=d1^m*sigmaA/((1-rho)*Ps);
                    c3=Pd*d1^m/(Ps*d2^m);
                    w(loop_rate)=d1^m*d4^m*sigmaE./(G2(loop_rate)*(1-rho)*Ps);

                    ECe=capatE(N(loop_rate),lambdaB,lambdaC,a2,b2,a3,b3,c3,w(loop_rate),t);
                    
                    EC=ECd-ECe;
                    
                    if EC < 0 | isnan( EC )
                        Cs(i) = 0;
                    else
                        Cs(i)=EC;
                    end
                    
                end            
        end       
        Cs_max(loop_ch)=max( Cs );       
    end
    Cs_avg(loop_rate)=mean(Cs_max)
end
plot(N,Cs_avg,'b-*')
xlabel('N','FontSize',12);
ylabel('$\bar{C}_s$ (bit/s/Hz)','interpreter','latex','FontSize',12,'FontWeight','Bold');
% title('P_s=20dBm,P_d=20dBm');
legend('\alpha=0.1(TSR)')
grid on;
set(gca,'GridLineStyle',':','GridColor','k', 'GridAlpha',0.8);
hold on;
